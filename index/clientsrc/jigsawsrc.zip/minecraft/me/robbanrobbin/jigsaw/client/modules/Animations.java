package me.robbanrobbin.jigsaw.client.modules;

import me.robbanrobbin.jigsaw.client.module.state.Category;
import me.robbanrobbin.jigsaw.module.Module;

public class Animations extends Module {

	public Animations() {
		super("Animations", 0, Category.FUN, "Changes some animations.");
	}

	public void onToggle() {

		super.onToggle();
	}
}
