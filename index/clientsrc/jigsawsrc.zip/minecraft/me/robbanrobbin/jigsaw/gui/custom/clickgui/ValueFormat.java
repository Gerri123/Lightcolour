package me.robbanrobbin.jigsaw.gui.custom.clickgui;

public enum ValueFormat {
	
	PERCENT, DECIMAL, INT
	
}
