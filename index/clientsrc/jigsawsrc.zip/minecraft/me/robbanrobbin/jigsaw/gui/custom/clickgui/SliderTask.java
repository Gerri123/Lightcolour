package me.robbanrobbin.jigsaw.gui.custom.clickgui;

public abstract class SliderTask {

	public abstract void task(Slider slider);

}
